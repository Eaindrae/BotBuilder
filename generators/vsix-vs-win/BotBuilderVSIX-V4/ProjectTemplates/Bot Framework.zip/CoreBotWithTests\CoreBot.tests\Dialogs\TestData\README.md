﻿# Note
This folder contains data generators and test case object definitions for Theory tests.

For additional details on how to create data driven tests with XUnit see [xUnit Theory: Working With InlineData, MemberData, ClassData](http://hamidmosalla.com/2017/02/25/xunit-theory-working-with-inlinedata-memberdata-classdata/)
